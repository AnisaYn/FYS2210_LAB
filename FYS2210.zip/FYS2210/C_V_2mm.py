import numpy as np
import matplotlib.pyplot as plt
from matplotlib.pyplot import*
# Gate lengde 2 mirco meter 
infile = open('w3_cv_2mm.txt')
V = []
C = []

for line in infile:
    words = line.split()
    
    V.append(float(words[0]))
    C.append(float(words[1]))



print words

V = np.array(V)
C = np.array(C)

infile.close()
print V
print C

figure(1)
fig, ax = plt.subplots()
ax.plot(V, C,"r-",linewidth=2, label='$d \mathcal{=2}mm $')

grid(True)
title('C_V karateristisk', fontsize=20)
xlabel('Voltage[V]', fontsize=16)
ylabel('Capacitance[C]',fontsize=16)

# Now add the legend with some customizations.
legend = ax.legend(loc='upper center', shadow=True)

# The frame is matplotlib.patches.Rectangle instance surrounding the legend.
frame = legend.get_frame()
frame.set_facecolor('0.90')

# Set the fontsize
for label in legend.get_texts():
    label.set_fontsize('large')

for label in legend.get_lines():
    label.set_linewidth(1.5)
show()