import numpy as np
import matplotlib.pyplot as plt
from matplotlib.pyplot import*
# Gate lengde 2 mirco meter 
infile = open('w3_vg_sweep_20um.txt')
V = []
I = []

for line in infile:
    words = line.split()
    
    V.append(float(words[0]))
    I.append(float(words[1]))



print words

V = np.array(V)
I = np.array(I)

infile.close()
print V
print I

figure(1)
fig, ax = plt.subplots()
ax.plot(V, I,"m-",linewidth=2, label='$G_l\mathcal{=20\mu}m $')

grid(True)
title('I_V sweep N-MOSFET', fontsize=20)
xlabel('Voltage[V]', fontsize=16)
ylabel('Current[I]',fontsize=16)

# Now add the legend with some customizations.
legend = ax.legend(loc='2', shadow=True)

# The frame is matplotlib.patches.Rectangle instance surrounding the legend.
frame = legend.get_frame()
frame.set_facecolor('0.90')

# Set the fontsize
for label in legend.get_texts():
    label.set_fontsize('large')

for label in legend.get_lines():
    label.set_linewidth(1.5)
show()