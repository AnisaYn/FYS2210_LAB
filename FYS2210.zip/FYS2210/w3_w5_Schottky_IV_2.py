import numpy as np
import matplotlib.pyplot as plt
from matplotlib.pyplot import*
# Gate lengde 2 mirco meter 
infile = open('w5_schottky_05mm_iv_optisk')
V = []
I = []

for line in infile:
    words = line.split()
    
    V.append(float(words[0]))
    I.append(float(words[1]))



print words

V = np.array(V)
I = np.array(I)

infile.close()
print V
print I

figure(1)
fig, ax = plt.subplots()
ax.plot(V, I,"y-",linewidth=2)
grid(True)
title('I_V karakteristisk av Schottky (0.5mm) optisk', fontsize=20)
xlabel('Voltage[V]', fontsize=16)
ylabel('Current[I]',fontsize=16)
show()
