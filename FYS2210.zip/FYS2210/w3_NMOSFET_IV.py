import numpy as np
import matplotlib.pyplot as plt
from matplotlib.pyplot import*
# Gate lengde 2 mirco meter 
infile = open('w3_NMOSFET_vg_4v_2um.txt')
V = []
I = []

for line in infile:
    words = line.split()
    
    V.append(float(words[0]))
    I.append(float(words[1]))



print words

V = np.array(V)
I = np.array(I)

infile.close()
print V
print I

figure(1)
fig, ax = plt.subplots()
ax.plot(V, I,"b-",linewidth=2, label='$G_l\mathcal{=2\mu}m $')
#legend('V2')


# Gate lengde 4 mirco meter
infile = open('w3_NMOSFET_vg_4v_4um.txt')
V1 = []
I1 = []

for line in infile:
    words = line.split()
    
    V1.append(float(words[0]))
    I1.append(float(words[1]))



print words

V1 = np.array(V1)
I1 = np.array(I1)

infile.close()
print V1
print I1

ax.plot(V1, I1,"r-",linewidth=2,label='$G_l\mathcal{=4\mu}m $')
#legend('V1')

# Gate legnde = 10 mirco meter
infile = open('w3_NMOSFET_vg_4v_10um.txt')
V2 = []
I2 = []

for line in infile:
    words = line.split()
    
    V2.append(float(words[0]))
    I2.append(float(words[1]))



print words

V2 = np.array(V2)
I2 = np.array(I2)

infile.close()
print V2
print I2
ax.plot(V2, I2,"g-",linewidth=2, label='$G_l\mathcal{=10\mu}m $')
#legend('V2')

# Gate lengde 20 mirco meter
infile = open('w3_NMOSFET_vg_4v_20um.txt')
V3 = []
I3 = []

for line in infile:
    words = line.split()
    
    V3.append(float(words[0]))
    I3.append(float(words[1]))



print words

V3 = np.array(V3)
I3 = np.array(I3)

infile.close()
print V3
print I3
ax.plot(V3, I3,"c-",linewidth=2,label='$G_l\mathcal{=20\mu}m $')
#legend('V3')

grid(True)
title('I_V Karkterisering av N-MOSFET; spenning=4V ', fontsize=20)
xlabel('Voltage[V]', fontsize=16)
ylabel('Current[I]',fontsize=16)

# Now add the legend with some customizations.
legend = ax.legend(loc='2', shadow=True)

# The frame is matplotlib.patches.Rectangle instance surrounding the legend.
frame = legend.get_frame()
frame.set_facecolor('0.90')

# Set the fontsize
for label in legend.get_texts():
    label.set_fontsize('large')

for label in legend.get_lines():
    label.set_linewidth(1.5)
show()
